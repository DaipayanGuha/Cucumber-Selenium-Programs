package com.cg.github.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage {
	
	@FindBy(how=How.ID,id="login_field")
	private WebElement username;
	
	@FindBy(how=How.ID,id="password")
	private WebElement password;
	
	@FindBy(className="btn")
	private WebElement button;
	
	//@FindBy(how=How.XPATH,xpath="//div[@class='container']\"")
	//private WebElement actualErrorMessage;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"js-flash-container\"]/div/div")
	private WebElement actualErrorMessage;
	
	public LoginPage() {}

	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getButton() {
		return button;
	}

	public String getActualErrorMessage() {
		return actualErrorMessage.getText();
	}

	public void clickSignIn() {
		button.submit();
	}
	
}

/*
 * package com.cg.github.pagebeans;
 * 
 * import org.openqa.selenium.WebElement; import
 * org.openqa.selenium.support.FindBy; import org.openqa.selenium.support.How;
 * 
 * public class LoginPage {
 * 
 * @FindBy(how=How.ID,id="login_field") private WebElement username;
 * 
 * @FindBy(how=How.ID,id="password") private WebElement password;
 * 
 * @FindBy(className="btn") private WebElement button;
 * 
 * @FindBy(how=How.XPATH,xpath="//div[@class='container']\"") private WebElement
 * actualErrorMessage;
 * 
 * public LoginPage() {}
 * 
 * public WebElement getUsername() { return username; }
 * 
 * public void setUsername(WebElement username) { this.username = username; }
 * 
 * public WebElement getPassword() { return password; }
 * 
 * public void setPassword(WebElement password) { this.password = password; }
 * 
 * public WebElement getButton() { return button; }
 * 
 * public void setButton(WebElement button) { this.button = button; }
 * 
 * public WebElement getActualErrorMessage() { return actualErrorMessage; }
 * 
 * public void setActualErrorMessage(WebElement actualErrorMessage) {
 * this.actualErrorMessage = actualErrorMessage; }
 * 
 * }
 */
