package com.cg.project.stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TempStepDefinition {

	@Given("^user is accessing login page$")
	public void user_is_accessing_login_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Given("^wants to login$")
	public void wants_to_login() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^user logins$")
	public void user_logins() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^input his/her valid credentials$")
	public void input_his_her_valid_credentials() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^click on login button$")
	public void click_on_login_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^he/she logins and gets redirected to his/her profile page$")
	public void he_she_logins_and_gets_redirected_to_his_her_profile_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^user logins with his/her invalid credentials$")
	public void user_logins_with_his_her_invalid_credentials() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^access to the account will be denied$")
	public void access_to_the_account_will_be_denied() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

}
